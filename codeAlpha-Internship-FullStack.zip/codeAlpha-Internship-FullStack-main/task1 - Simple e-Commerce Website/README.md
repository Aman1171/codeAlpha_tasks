


Navigate to the backend directory in your terminal.
Install dependencies: npm install
Start the server: npm start
Frontend
Simply open frontend/index.html in your browser.