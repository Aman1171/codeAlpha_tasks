# functional Requirements and notes
Light/Dark Mode toggle

-what Html Markup #also mention their links

-Switching Btw Light/Dark mode

Css Variables (custom Properties)

Prefers-color-scheme media query

Accessibility
- Use write heading tags
- Screenreader-only text for card titles/useername
